#include <iostream>
#include <fstream>
#include <vector>
#include <string>
#include <iomanip>
#include <sstream>
#include <algorithm>
#include <ctime>
#include <limits>

using namespace std;

// 
//  Constants
// 
const string BOOKS_FILE = "books.dat";
const string MEMBERS_FILE = "members.dat";
const string ISSUED_FILE = "issued.dat";
const double DAILY_FINE = 5.0;   // Rs 5 per day overdue
const int    LOAN_DAYS = 14;    // 2-week loan period

// 
//  Structs
//
struct Book {
    int    bookID = 0;
    string title;
    string author;
    string ISBN;
    int    totalCopies = 0;
    int    availableCopies = 0;
    double price = 0.0;
};

struct Member {
    int    memberID = 0;
    string name;
    string email;
    string joinDate;
    int    booksIssued = 0;   // currently borrowed
};

struct IssuedBook {
    int    recordID = 0;
    int    bookID = 0;
    int    memberID = 0;
    string issueDate;
    string dueDate;
    double fineAmount = 0.0;
    bool   isReturned = false;
};

// 
//  Global state
// 
vector<Book>       books;
vector<Member>     members;
vector<IssuedBook> issuedRecords;

int nextBookID = 101;
int nextMemberID = 201;
int nextRecordID = 301;

// 
//  Utility helpers
//

string currentDate() {
    time_t now = time(0);
    tm t{};
#ifdef _WIN32
    localtime_s(&t, &now);
#else
    localtime_r(&now, &t);
#endif
    char buf[11];
    strftime(buf, sizeof(buf), "%Y-%m-%d", &t);
    return string(buf);
}

// Add LOAN_DAYS to a YYYY-MM-DD date string
string addDays(const string& dateStr, int days) {
    int y, m, d;
#ifdef _WIN32
    sscanf_s(dateStr.c_str(), "%d-%d-%d", &y, &m, &d);
#else
    sscanf(dateStr.c_str(), "%d-%d-%d", &y, &m, &d);
#endif

    tm t{};
    t.tm_year = y - 1900;
    t.tm_mon = m - 1;
    t.tm_mday = d + days;
    mktime(&t);   // normalises overflow (e.g. Feb 30 -> Mar 2)

    char buf[11];
    strftime(buf, sizeof(buf), "%Y-%m-%d", &t);
    return string(buf);
}

// Returns days between two YYYY-MM-DD strings (b - a)
int daysBetween(const string& a, const string& b) {
    auto toTime = [](const string& s) -> time_t {
        int y, m, d;
#ifdef _WIN32
        sscanf_s(s.c_str(), "%d-%d-%d", &y, &m, &d);
#else
        sscanf(s.c_str(), "%d-%d-%d", &y, &m, &d);
#endif
        tm t{};
        t.tm_year = y - 1900;
        t.tm_mon = m - 1;
        t.tm_mday = d;
        t.tm_isdst = -1;
        return mktime(&t);
        };
    double diff = difftime(toTime(b), toTime(a));
    return (int)(diff / 86400.0);
}

void clearInput() {
    cin.clear();
    cin.ignore(numeric_limits<streamsize>::max(), '\n');
}

string toLower(const string& s) {
    string out = s;
    transform(out.begin(), out.end(), out.begin(), ::tolower);
    return out;
}

void divider(int w = 70) { cout << string(w, '-') << "\n"; }

// Pointer-based finders
Book* findBook(int id) { for (auto& b : books)   if (b.bookID == id) return &b;   return nullptr; }
Member* findMember(int id) { for (auto& m : members) if (m.memberID == id) return &m;   return nullptr; }
IssuedBook* findActiveIssue(int bookID, int memberID) {
    for (auto& r : issuedRecords)
        if (r.bookID == bookID && r.memberID == memberID && !r.isReturned)
            return &r;
    return nullptr;
}

// 
//  File I/O
// 

void saveBooks() {
    ofstream f(BOOKS_FILE);
    if (!f) { cout << "  [Error] Cannot save books.\n"; return; }
    f << nextBookID << "\n" << books.size() << "\n";
    for (const auto& b : books)
        f << b.bookID << "|" << b.title << "|" << b.author << "|"
        << b.ISBN << "|" << b.totalCopies << "|"
        << b.availableCopies << "|"
        << fixed << setprecision(2) << b.price << "\n";
    f.close();
}

void loadBooks() {
    ifstream f(BOOKS_FILE);
    if (!f) return;
    f >> nextBookID;
    int count; f >> count; f.ignore();
    books.clear();
    for (int i = 0; i < count; i++) {
        string line; if (!getline(f, line)) break;
        stringstream ss(line); string tok;
        Book b;
        getline(ss, tok, '|'); b.bookID = stoi(tok);
        getline(ss, b.title, '|');
        getline(ss, b.author, '|');
        getline(ss, b.ISBN, '|');
        getline(ss, tok, '|'); b.totalCopies = stoi(tok);
        getline(ss, tok, '|'); b.availableCopies = stoi(tok);
        getline(ss, tok);      b.price = stod(tok);
        books.push_back(b);
    }
    f.close();
}

void saveMembers() {
    ofstream f(MEMBERS_FILE);
    if (!f) { cout << "  [Error] Cannot save members.\n"; return; }
    f << nextMemberID << "\n" << members.size() << "\n";
    for (const auto& m : members)
        f << m.memberID << "|" << m.name << "|" << m.email << "|"
        << m.joinDate << "|" << m.booksIssued << "\n";
    f.close();
}

void loadMembers() {
    ifstream f(MEMBERS_FILE);
    if (!f) return;
    f >> nextMemberID;
    int count; f >> count; f.ignore();
    members.clear();
    for (int i = 0; i < count; i++) {
        string line; if (!getline(f, line)) break;
        stringstream ss(line); string tok;
        Member m;
        getline(ss, tok, '|');  m.memberID = stoi(tok);
        getline(ss, m.name, '|');
        getline(ss, m.email, '|');
        getline(ss, m.joinDate, '|');
        getline(ss, tok);       m.booksIssued = stoi(tok);
        members.push_back(m);
    }
    f.close();
}

void saveIssued() {
    ofstream f(ISSUED_FILE);
    if (!f) { cout << "  [Error] Cannot save issued records.\n"; return; }
    f << nextRecordID << "\n" << issuedRecords.size() << "\n";
    for (const auto& r : issuedRecords)
        f << r.recordID << "|" << r.bookID << "|" << r.memberID << "|"
        << r.issueDate << "|" << r.dueDate << "|"
        << fixed << setprecision(2) << r.fineAmount << "|"
        << r.isReturned << "\n";
    f.close();
}

void loadIssued() {
    ifstream f(ISSUED_FILE);
    if (!f) return;
    f >> nextRecordID;
    int count; f >> count; f.ignore();
    issuedRecords.clear();
    for (int i = 0; i < count; i++) {
        string line; if (!getline(f, line)) break;
        stringstream ss(line); string tok;
        IssuedBook r;
        getline(ss, tok, '|'); r.recordID = stoi(tok);
        getline(ss, tok, '|'); r.bookID = stoi(tok);
        getline(ss, tok, '|'); r.memberID = stoi(tok);
        getline(ss, r.issueDate, '|');
        getline(ss, r.dueDate, '|');
        getline(ss, tok, '|');  r.fineAmount = stod(tok);
        getline(ss, tok);       r.isReturned = (tok == "1");
        issuedRecords.push_back(r);
    }
    f.close();
}

void saveAll() { saveBooks(); saveMembers(); saveIssued(); }

// 
//  Fine calculation
// 

double calculateFine(const string& dueDate) {
    string today = currentDate();
    int overdue = daysBetween(dueDate, today);
    if (overdue <= 0) return 0.0;
    return overdue * DAILY_FINE;
}

//
//  Core features
//

void addBook() {
    cout << "\n  --- ADD NEW BOOK ---\n";
    Book b;
    b.bookID = nextBookID++;

    cin.ignore();
    cout << "  Title  : "; getline(cin, b.title);
    if (b.title.empty()) { cout << "  [Error] Title cannot be empty.\n"; nextBookID--; return; }
    cout << "  Author : "; getline(cin, b.author);
    cout << "  ISBN   : "; getline(cin, b.ISBN);

    cout << "  Total Copies : ";
    if (!(cin >> b.totalCopies) || b.totalCopies <= 0) {
        cout << "  [Error] Invalid quantity.\n"; clearInput(); nextBookID--; return;
    }
    b.availableCopies = b.totalCopies;

    cout << "  Price (Rs)   : ";
    if (!(cin >> b.price) || b.price < 0) {
        cout << "  [Error] Invalid price.\n"; clearInput(); nextBookID--; return;
    }

    books.push_back(b);
    saveAll();

    cout << "  Book added! ID: " << b.bookID << "\n";
}

void addMember() {
    cout << "\n  --- ADD NEW MEMBER ---\n";
    Member m;
    m.memberID = nextMemberID++;

    cin.ignore();
    cout << "  Name  : "; getline(cin, m.name);
    if (m.name.empty()) { cout << "  [Error] Name cannot be empty.\n"; nextMemberID--; return; }
    cout << "  Email : "; getline(cin, m.email);
    m.joinDate = currentDate();
    m.booksIssued = 0;

    members.push_back(m);
    saveAll();

    cout << "  Member registered! ID: " << m.memberID << "\n";
}

void issueBook() {
    cout << "\n  --- ISSUE BOOK ---\n";
    if (books.empty()) { cout << "  No books in system.\n";   return; }
    if (members.empty()) { cout << "  No members in system.\n"; return; }

    int bookID, memberID;
    cout << "  Book ID   : "; if (!(cin >> bookID)) { clearInput(); return; }
    cout << "  Member ID : "; if (!(cin >> memberID)) { clearInput(); return; }

    // Pointer-based lookup
    Book* book = findBook(bookID);
    Member* member = findMember(memberID);

    if (!book) { cout << "  [Error] Book not found.\n";   return; }
    if (!member) { cout << "  [Error] Member not found.\n"; return; }
    if (book->availableCopies <= 0) {
        cout << "  [Error] No copies available for \"" << book->title << "\".\n"; return;
    }

    // Check if member already has this book
    if (findActiveIssue(bookID, memberID)) {
        cout << "  [Error] Member already has this book.\n"; return;
    }

    // Issue via pointers
    book->availableCopies--;
    member->booksIssued++;

    IssuedBook r;
    r.recordID = nextRecordID++;
    r.bookID = bookID;
    r.memberID = memberID;
    r.issueDate = currentDate();
    r.dueDate = addDays(r.issueDate, LOAN_DAYS);
    r.fineAmount = 0.0;
    r.isReturned = false;
    issuedRecords.push_back(r);
    saveAll();

    cout << "  Book issued successfully!\n";
    cout << "  \"" << book->title << "\" -> " << member->name << "\n";
    cout << "  Issue Date : " << r.issueDate << "\n";
    cout << "  Due Date   : " << r.dueDate << "\n";
}

void returnBook() {
    cout << "\n  --- RETURN BOOK ---\n";

    int bookID, memberID;
    cout << "  Book ID   : "; if (!(cin >> bookID)) { clearInput(); return; }
    cout << "  Member ID : "; if (!(cin >> memberID)) { clearInput(); return; }

    Book* book = findBook(bookID);
    Member* member = findMember(memberID);
    IssuedBook* record = findActiveIssue(bookID, memberID);

    if (!book) { cout << "  [Error] Book not found.\n";           return; }
    if (!member) { cout << "  [Error] Member not found.\n";         return; }
    if (!record) { cout << "  [Error] No active issue found.\n";    return; }

    // Calculate fine via pointer
    record->fineAmount = calculateFine(record->dueDate);
    record->isReturned = true;

    // Update counts via pointers
    book->availableCopies++;
    if (member->booksIssued > 0) member->booksIssued--;

    saveAll();

    cout << "  Book returned: \"" << book->title << "\" from " << member->name << "\n";
    cout << "  Return Date  : " << currentDate() << "\n";
    if (record->fineAmount > 0)
        cout << "  Fine Due     : Rs " << fixed << setprecision(2) << record->fineAmount << "\n";
    else
        cout << "  No fine. Returned on time!\n";
}

void searchBook() {
    cout << "\n  --- SEARCH BOOK ---\n";
    cin.ignore();
    string query;
    cout << "  Enter title or ISBN: "; getline(cin, query);
    string lq = toLower(query);

    bool found = false;
    divider();
    cout << left << setw(6) << "ID"
        << setw(28) << "Title"
        << setw(18) << "Author"
        << setw(8) << "Avail"
        << setw(10) << "ISBN" << "\n";
    divider();

    for (const auto& b : books) {
        if (toLower(b.title).find(lq) != string::npos ||
            toLower(b.ISBN).find(lq) != string::npos) {
            cout << left << setw(6) << b.bookID
                << setw(28) << b.title.substr(0, 26)
                << setw(18) << b.author.substr(0, 16)
                << setw(8) << b.availableCopies
                << setw(10) << b.ISBN << "\n";
            found = true;
        }
    }
    if (!found) cout << "  No matching books found.\n";
    divider();
}

void viewAllBooks() {
    cout << "\n  --- ALL BOOKS ---\n";
    if (books.empty()) { cout << "  No books in library.\n"; return; }

    divider(75);
    cout << left << setw(6) << "ID"
        << setw(26) << "Title"
        << setw(18) << "Author"
        << setw(7) << "Total"
        << setw(7) << "Avail"
        << setw(11) << "Price (Rs)" << "\n";
    divider(75);

    for (const auto& b : books) {
        cout << left << setw(6) << b.bookID
            << setw(26) << b.title.substr(0, 24)
            << setw(18) << b.author.substr(0, 16)
            << setw(7) << b.totalCopies
            << setw(7) << b.availableCopies
            << fixed << setprecision(2) << b.price << "\n";
    }
    divider(75);
    cout << "  Total books: " << books.size() << "\n";
}

void viewAllMembers() {
    cout << "\n  --- ALL MEMBERS ---\n";
    if (members.empty()) { cout << "  No members registered.\n"; return; }

    divider(65);
    cout << left << setw(8) << "ID"
        << setw(22) << "Name"
        << setw(25) << "Email"
        << setw(10) << "Borrowed" << "\n";
    divider(65);

    for (const auto& m : members) {
        cout << left << setw(8) << m.memberID
            << setw(22) << m.name.substr(0, 20)
            << setw(25) << m.email.substr(0, 23)
            << setw(10) << m.booksIssued << "\n";
    }
    divider(65);
    cout << "  Total members: " << members.size() << "\n";
}

void memberHistory() {
    cout << "\n  --- MEMBER BORROW HISTORY ---\n";
    int memberID;
    cout << "  Member ID: "; if (!(cin >> memberID)) { clearInput(); return; }

    Member* m = findMember(memberID);
    if (!m) { cout << "  [Error] Member not found.\n"; return; }

    cout << "\n  Member : " << m->name << " (ID: " << m->memberID << ")\n";
    divider(70);
    cout << left << setw(8) << "BookID"
        << setw(24) << "Title"
        << setw(12) << "Issue Date"
        << setw(12) << "Due Date"
        << setw(10) << "Status"
        << setw(10) << "Fine" << "\n";
    divider(70);

    bool found = false;
    for (const auto& r : issuedRecords) {
        if (r.memberID == memberID) {
            Book* b = findBook(r.bookID);
            string title = b ? b->title.substr(0, 22) : "Unknown";
            string status = r.isReturned ? "Returned" : "Active";
            cout << left << setw(8) << r.bookID
                << setw(24) << title
                << setw(12) << r.issueDate
                << setw(12) << r.dueDate
                << setw(10) << status
                << "Rs " << fixed << setprecision(2) << r.fineAmount << "\n";
            found = true;
        }
    }
    if (!found) cout << "  No borrow history found.\n";
    divider(70);
}

void viewActiveIssues() {
    cout << "\n  --- CURRENTLY ISSUED BOOKS ---\n";
    bool found = false;

    divider(75);
    cout << left << setw(8) << "BookID"
        << setw(22) << "Title"
        << setw(20) << "Member"
        << setw(12) << "Due Date"
        << setw(13) << "Est. Fine" << "\n";
    divider(75);

    for (const auto& r : issuedRecords) {
        if (!r.isReturned) {
            Book* b = findBook(r.bookID);
            Member* m = findMember(r.memberID);
            string title = b ? b->title.substr(0, 20) : "Unknown";
            string mname = m ? m->name.substr(0, 18) : "Unknown";
            double estFine = calculateFine(r.dueDate);
            cout << left << setw(8) << r.bookID
                << setw(22) << title
                << setw(20) << mname
                << setw(12) << r.dueDate
                << "Rs " << fixed << setprecision(2) << estFine << "\n";
            found = true;
        }
    }
    if (!found) cout << "  No books currently issued.\n";
    divider(75);
}

void financeReport() {
    cout << "\n  ==================================\n";
    cout << "       LIBRARY FINANCE REPORT\n";
    cout << "  ==================================\n";
    cout << "  Generated : " << currentDate() << "\n\n";

    int    totalIssued = 0, totalReturned = 0, overdueCount = 0;
    double totalFines = 0.0, pendingFines = 0.0;
    string today = currentDate();

    for (const auto& r : issuedRecords) {
        totalIssued++;
        if (r.isReturned) {
            totalReturned++;
            totalFines += r.fineAmount;
        }
        else {
            double est = calculateFine(r.dueDate);
            if (est > 0) { overdueCount++; pendingFines += est; }
        }
    }

    double bookValue = 0.0;
    for (const auto& b : books) bookValue += b.price * b.totalCopies;

    cout << "  Total Books      : " << books.size() << "\n";
    cout << "  Total Members    : " << members.size() << "\n";
    cout << "  Total Issued     : " << totalIssued << "\n";
    cout << "  Currently Out    : " << (totalIssued - totalReturned) << "\n";
    cout << "  Overdue Books    : " << overdueCount << "\n";
    cout << "  Fines Collected  : Rs " << fixed << setprecision(2) << totalFines << "\n";
    cout << "  Pending Fines    : Rs " << pendingFines << "\n";
    cout << "  Total Book Value : Rs " << bookValue << "\n";
    cout << "  ==================================\n";
}

void deleteBook() {
    cout << "\n  --- DELETE BOOK ---\n";
    int id;
    cout << "  Book ID: "; if (!(cin >> id)) { clearInput(); return; }

    for (auto it = books.begin(); it != books.end(); ++it) {
        if (it->bookID == id) {
            if (it->availableCopies < it->totalCopies) {
                cout << "  [Error] Cannot delete — some copies are currently issued.\n"; return;
            }
            cout << "  Deleted: \"" << it->title << "\"\n";
            books.erase(it);
            saveAll();
            return;
        }
    }
    cout << "  [Error] Book not found.\n";
}

//
//  Menu
// 

void printMenu() {
    cout << "\n  +====================================+\n";
    cout << "  |   CloudExify Library System        |\n";
    cout << "  +====================================+\n";
    cout << "  |  -- Books --                       |\n";
    cout << "  |  1.  Add New Book                  |\n";
    cout << "  |  2.  View All Books                |\n";
    cout << "  |  3.  Search Book (title / ISBN)    |\n";
    cout << "  |  4.  Delete Book                   |\n";
    cout << "  |  -- Members --                     |\n";
    cout << "  |  5.  Add New Member                |\n";
    cout << "  |  6.  View All Members              |\n";
    cout << "  |  7.  Member Borrow History         |\n";
    cout << "  |  -- Borrowing --                   |\n";
    cout << "  |  8.  Issue Book                    |\n";
    cout << "  |  9.  Return Book                   |\n";
    cout << "  |  10. View Currently Issued         |\n";
    cout << "  |  -- Reports --                     |\n";
    cout << "  |  11. Finance Report                |\n";
    cout << "  |  0.  Save & Exit                   |\n";
    cout << "  +====================================+\n";
    cout << "  Choice: ";
}

int main() {
    loadBooks();
    loadMembers();
    loadIssued();

    cout << "\n  Welcome to CloudExify Library System\n";
    cout << "  " << books.size() << " book(s), "
        << members.size() << " member(s) loaded.\n";

    int choice;
    while (true) {
        printMenu();
        if (!(cin >> choice)) { clearInput(); continue; }

        switch (choice) {
        case 1:  addBook();          break;
        case 2:  viewAllBooks();     break;
        case 3:  searchBook();       break;
        case 4:  deleteBook();       break;
        case 5:  addMember();        break;
        case 6:  viewAllMembers();   break;
        case 7:  memberHistory();    break;
        case 8:  issueBook();        break;
        case 9:  returnBook();       break;
        case 10: viewActiveIssues(); break;
        case 11: financeReport();    break;
        case 0:
            saveAll();
            cout << "\n  All data saved. Goodbye!\n\n";
            return 0;
        default:
            cout << "  [Error] Invalid option.\n";
        }
    }
}