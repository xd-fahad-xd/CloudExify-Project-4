# CloudExify Internship 2026- C++ Month 2, Project 4

## Library Management System



## Overview

A console-based library management system built in C++ that handles books, members, and borrowing records. Uses **pointers and dynamic memory** to manage inventory efficiently, with full file persistence across sessions. This is the capstone project of the CloudExify C++ Internship.



## Features

**Books**

* Add new book with ISBN, title, author, quantity, and price
* View all books with availability status
* Search book by title or ISBN (partial, case-insensitive)
* Delete book (blocked if copies are currently issued)

**Members**

* Register new library member with name and email
* View all registered members
* View full borrow history for any member

**Borrowing**

* Issue book to member (availability checked via pointers)
* Return book with automatic fine calculation
* View all currently issued books with estimated fines

**Reports**

* Finance report — fines collected, pending fines, overdue count, total book value



## Concepts Used

|Concept|Where Used|
|-|-|
|Pointers (`\*`, `\&`)|`findBook()`, `findMember()` return typed pointers; issue/return modify via `->`|
|Dynamic memory|`vector<Book>`, `vector<Member>`, `vector<IssuedBook>` grow at runtime|
|Structs|`Book`, `Member`, `IssuedBook`|
|File I/O|`books.dat`, `members.dat`, `issued.dat`|
|String manipulation|Search, pipe-delimited parsing, date formatting|
|Date arithmetic|Due date calculation, fine computation (days overdue \* Rs 5)|



## Fine Policy

* Loan period: **14 days**
* Fine rate: **Rs 5 per day** overdue
* Fine is calculated automatically on return





## File Structure


main.cpp       — Main source code
books.dat         — Auto-generated; stores all book records
members.dat       — Auto-generated; stores all member records
issued.dat        — Auto-generated; stores all borrow records
README.md         — This file


